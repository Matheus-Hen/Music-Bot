import { client } from '../index.js'
export const interactionCreate = () => {

  client.on('interactionCreate', async interaction => {
    if (!interaction.isChatInputCommand()) return;

    if (interaction.commandName === 'ping') {
      await interaction.reply("!Pong")
    }
  });

  client.login("MTAzNDA5NjQ2ODE2NTkzNTEwNA.G--X8_.JYPFQFjtnLAwZLgFaMvLOr807ReDZraiQsVr2U")
}
